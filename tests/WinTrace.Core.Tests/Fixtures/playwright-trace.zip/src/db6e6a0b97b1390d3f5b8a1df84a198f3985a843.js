const {chromium}=require('playwright');const http=require('http');
const page=`<html><body><h1>Customers</h1><input data-testid="name"><input type="password" id="password"><button id="save" onclick="console.error('save failed: validation');fetch('/api/customers',{method:'POST'})">Save</button></body></html>`;
const srv=http.createServer((q,r)=>{ if(q.url.startsWith('/api/')){r.writeHead(500);return r.end('error')} r.writeHead(200,{'content-type':'text/html'});r.end(page)});
srv.listen(4802,async()=>{const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:640,height:360}});
await ctx.tracing.start({screenshots:true,snapshots:true,sources:true});
const p=await ctx.newPage();
await p.goto('http://127.0.0.1:4802/');
await p.getByTestId('name').fill('Ada Lovelace');
await p.locator('#password').fill('hunter2');
await p.click('#save');
await p.waitForTimeout(200);
try{await p.click('#submit',{timeout:400})}catch(e){}
await ctx.tracing.stop({path:'playwright-trace.zip'});await b.close();srv.close();console.log('ok')})
